local physics = require( 'physics' )
local composer = require( "composer" )

-- Initialize variables

local gameLoopTimer
local gameLoop2Timer
local timerLoop
local timerMloop
local EnTable = {}
local uiGroup = display.newGroup()
local score = 0
local health = 10
local timer1 = 0
local healthText = display.newText(  uiGroup, "Health: " ..health, 200, 80, native.systemFont, 36 )
local scoreText = display.newText(  uiGroup, "score: " ..score, 400, 80, native.systemFont, 36 )
local timerText = display.newText(  uiGroup, "timer: " ..timer1, 600, 80, native.systemFont, 36 )
local died = false

local function time()
timer1 = timer1 + 1
timerText.text ="timer:".. timer1
end

local function createEn1()
local  en = display.newRect( math.random(250,1900), math.random(200,1000), 30, 30 )
  en:setFillColor(1,0,0)
  table.insert( EnTable, En )
  physics.addBody( en, "static", {density = 0, friction = 0.5, bounce = 0.8} )

  en.myName = "en1"
end

local function createEn2()
local  en = display.newRect( math.random(250,1900), math.random(200,1000), 30, 30 )
  en:setFillColor(0,1,0)
  table.insert( EnTable, En )
  physics.addBody( en, "static", {density = 0, friction = 0.5, bounce = 0.8} )

  en.myName = "en1"
end
local function createEn3()
local  en = display.newRect( math.random(250,1900), math.random(200,1000), 30, 30 )
  en:setFillColor(0,0,1)
  table.insert( EnTable, En )
  physics.addBody( en, "static", {density = 0, friction = 0.5, bounce = 0.8} )

  en.myName = "en1"
end
local function createEn4()
local  en = display.newRect( math.random(250,1900), math.random(200,1000), 30, 30 )
  en:setFillColor(1,1,1)
  table.insert( EnTable, En )
  physics.addBody( en, "static", {density = 0, friction = 0.5, bounce = 0.8} )

  en.myName = "en1"
end
--char
local sqr = display.newRect(200,200,30,30)
sqr:setFillColor(1,1,0)
sqr.myName = "sqr"

-- wall
local Wall1 = display.newRect(1920,540,10,1080)
Wall1:setFillColor(1,1,0)
local Wall2 = display.newRect(960,0,1920,10)
Wall2:setFillColor(0,1,1)
local Wall3 = display.newRect(960,1080,1920,10)
Wall3:setFillColor(0,1,1)
local Wall4 = display.newRect(0,540,10,1080)
Wall4:setFillColor(0,1,0)
--local door = display.newRect(1000,540,10,180)
--door:setFillColor(0,0,1)


display.setDefault("background", 0,0,0)
sqr.isFixedRotation = true

physics.start()
physics.setGravity( 0, 0 )
physics.addBody( Wall1, "static", {friction=0.5, bounce=10.3} )
physics.addBody( Wall2, "static", {friction=0.5, bounce=10.3}  )
physics.addBody( Wall3, "static", {friction=0.5, bounce=10.3}  )
physics.addBody( Wall4, "static", {friction=0.5, bounce=10.3}  )
physics.addBody( sqr,"dynamic" )
--physics.addBody( door, "static", {density = 10, friction=0.5, bounce=10} )


--moving
local upPressed = false
local downPressed = false
local leftPressed = false
local rightPressed = false
--shooting
local bulletup = false
local bulletdown = false
local bulletleft = false
local bulletright = false
--sprint
local Sprint = false


local function key( event)

    if (event.phase == "down") then
        if (event.keyName == "w") then
            upPressed = true
        elseif (event.keyName == "s") then
            downPressed = true
        elseif (event.keyName == "a") then
            leftPressed = true
        elseif (event.keyName == "d") then
            rightPressed = true
        elseif (event.keyName == "leftShift") then
            Sprint = true
        elseif (event.keyName == "up") then
            bulletup = true
        elseif (event.keyName == "down") then
           bulletdown = true
       elseif (event.keyName == "left") then
          bulletleft = true
        elseif (event.keyName == "right") then
          bulletright = true
    end


    elseif (event.phase == "up") then
        if (event.keyName == "w") then
            upPressed = false
        elseif (event.keyName == "s") then
            downPressed = false
        elseif (event.keyName == "a") then
            leftPressed = false
        elseif (event.keyName == "d") then
            rightPressed = false
       elseif (event.keyName == "leftShift") then
           Sprint = false
        elseif (event.keyName == "up") then
            bulletup = false
        elseif (event.keyName == "down") then
            bulletdown = false
        elseif (event.keyName == "left") then
            bulletleft = false
        elseif (event.keyName == "right") then
            bulletright = false
  end
    end



    if (bulletup) then
    bulletup =  display.newCircle( sqr.x, sqr.y-15, 4 )
      physics.addBody( bulletup, "dynamic",{radius = 4} )
      bulletup.gravityScale = 0
      bulletup.isBullet = true
      bulletup.isSensor = true
      bulletup:setLinearVelocity(0,-400)
      bulletup.myName = "bullet"


    elseif (bulletdown) then
    bulletdown =  display.newCircle( sqr.x+15, sqr.y, 4 )
      physics.addBody( bulletdown, "dynamic",{radius = 4} )
      bulletdown.gravityScale = 0
      bulletdown.isBullet = true
      bulletdown.isSensor = true
      bulletdown:setLinearVelocity(0,400)
      bulletdown.myName = "bullet"

    elseif (bulletleft) then
    bulletleft =  display.newCircle( sqr.x-15, sqr.y, 4 )
      physics.addBody( bulletleft, "dynamic",{radius = 4})
      bulletleft.gravityScale = 0
      bulletleft.isBullet = true
      bulletleft.isSensor = true
      bulletleft:setLinearVelocity(-400,0)
      bulletleft.myName = "bullet"
    elseif (bulletright) then
    bulletright =  display.newCircle( sqr.x+15, sqr.y, 4 )
      physics.addBody( bulletright, "dynamic",{radius = 4} )
      bulletright.gravityScale = 0
      bulletright.isBullet = true
      bulletright.isSensor = true
      bulletright:setLinearVelocity(400,0)
      bulletright.myName = "bullet"
end
  end




--sqr movement
local function sqrEnterFrame( event )
    if (Sprint) then
      if (upPressed) then
          sqr.y = sqr.y - 10
      end
      if (downPressed) then
          sqr.y = sqr.y + 10
      end
      if (leftPressed) then
          sqr.x = sqr.x - 10
      end
      if (rightPressed) then
          sqr.x = sqr.x + 10
      end

end

    if (upPressed) then
        sqr.y = sqr.y - 5
    end
    if (downPressed) then
        sqr.y = sqr.y + 5
    end
    if (leftPressed) then
        sqr.x = sqr.x - 5
    end
    if (rightPressed) then
        sqr.x = sqr.x + 5
    end


end

local function enMove()
if (not en1 == sqr) then
 en1:transition.to(sqr)
end
local function gameLoop()
-- create enemy
    createEn1()
    createEn2()
    createEn3()
    createEn4()


end


local function onCollision( event )

    if ( event.phase == "began" ) then

        local obj1 = event.object1
        local obj2 = event.object2

        if ( ( obj1.myName == "bullet" and obj2.myName == "en1" ) or
        ( obj1.myName == "en1" and obj2.myName == "bullet" ) )
then
display.remove( obj1 )
display.remove( obj2 )
score = score + 1
scoreText.text = "score:"..score


   elseif ( ( obj1.myName == "sqr" and obj2.myName == "en1" ) or
            ( obj1.myName == "en1" and obj2.myName == "sqr" ) )
   then

       health = health - 1.
       healthText.text ="health:".. health

       if (health == 0)  then
       health = health + 1

     end
  end
  end
end




--timer.performWithDelay( 1000, stuff, 0 )
Runtime:addEventListener( "key", key)
Runtime:addEventListener( "enterFrame", sqrEnterFrame )
Runtime:addEventListener( "collision", onCollision )
gameLoopTimer = timer.performWithDelay(math.random(1000, 5000), gameLoop,0)
--gameLoop2Timer = timer.performWithDelay(500, gameLoop2,0)
timerLoop = timer.performWithDelay(1000, time,0)
timerMloop = timer.performWithDelay( 5,"enMove" ,0 )
